Foram utilizadas, além da biblioteca <stdio.h> da linguagem C,
as bibliotecas <stdlib.h> e <math.h>.

Da biblioteca <stdlib.h>, foi utilizada a função "system", para
previnir o fechamento da janela do executável e permitir a
visualição do output.

Da biblioteca <math.h>, foram utilizadas as funções "pow" e "sqrt"
para realizar operações de potência e raiz quadrada, respectivamente.

Infelizmente não consegui formatar corretamente os caracteres especiais
nos execútaveis. Peço perdão pelo infortúnio.